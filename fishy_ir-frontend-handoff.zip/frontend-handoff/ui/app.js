/* fishy_ir UI client — vanilla JS, no deps, offline-safe.
 * Server contract: see /api/docs and openapi.yaml. */
"use strict";

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

/* ------------------------------------------------------------ api client */
const API = {
  /* Standalone mode: run this UI against the service from another
   * origin/port - either ?base=http://host:8385 on the page URL, or set
   * localStorage.fishyBase once (see API.md §"CORS & standalone").
   * Empty = same origin, the normal deployment. */
  base: (new URLSearchParams(location.search).get("base")
         || localStorage.getItem("fishyBase") || "").replace(/\/+$/, ""),
  url(path) { return this.base + path; },
  token: localStorage.getItem("fishyToken") || null,
  async req(path, opts = {}) {
    const h = Object.assign({}, opts.headers || {});
    if (this.token) h["X-Fishy-Token"] = this.token;
    if (opts.body !== undefined) h["Content-Type"] = "application/json";
    const r = await fetch(this.url(path), Object.assign({}, opts, { headers: h }));
    let body = null;
    try { body = await r.json(); } catch (e) { /* empty */ }
    if (!r.ok) {
      const err = new Error((body && body.error) || ("HTTP " + r.status));
      err.status = r.status;
      err.body = body;
      throw err;
    }
    return body;
  },
  setToken(t) { this.token = t || null; localStorage.setItem("fishyToken", t || ""); },
};

/* ----------------------------------------------------------------- views */
let VIEW = "queue";
function show(view) {
  VIEW = view;
  $$("#nav-view, nav button").forEach(b => b.classList.toggle("on", b.dataset.view === view));
  $$("main section").forEach(s => { s.hidden = s.id !== "view-" + view; });
  if (view === "queue") refreshQueue();
  if (view === "live") refreshLive(true);
  if (view === "results") refreshResults();
  if (view === "settings") refreshSettings();
  if (view === "api") refreshApi();
}
$$("nav button").forEach(b => b.addEventListener("click", () => show(b.dataset.view)));

/* ---------------------------------------------------------------- toasts */
function toast(msg, isErr) {
  const t = document.createElement("div");
  t.className = "toast" + (isErr ? " err" : "");
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => t.remove(), 5200);
}

/* ------------------------------------------------------------- banners -- */
function refreshBanners(h) {
  const b = $("#banners");
  b.innerHTML = "";
  if (h && h.background && h.background.warning) {
    const d = document.createElement("div");
    d.className = "banner warn";
    d.innerHTML = "&#9888; " + h.background.warning;
    if (!h.busy) {
      const btn = document.createElement("button");
      btn.className = "rowbtn";
      btn.textContent = "Measure background now →";
      btn.onclick = () => startBackgroundJob();
      d.appendChild(btn);
    }
    b.appendChild(d);
  }
}

async function startBackgroundJob() {
  try {
    const name = "background-" + stamp();
    const r = await API.req("/api/jobs", {
      method: "POST",
      body: JSON.stringify({ name, kind: "background", params: {}, start_now: true }),
    });
    toast("Background started (" + r.job.id.slice(0, 8) + ")");
    show("live");
    refreshQueue();
  } catch (e) {
    toast("Could not start: " + e.message, true);
    if (e.status === 401) promptToken();
  }
}

function stamp() {
  const d = new Date();
  const p = n => String(n).padStart(2, "0");
  return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "_" +
         p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
}

/* ----------------------------------------------------------------- queue */
function formPayload(startNow) {
  return {
    kind: $("#f-kind").value,
    name: $("#f-name").value.trim() || "",
    notes: $("#f-notes").value.trim(),
    params: {
      scans: +$("#f-scans").value,
      resolution: +$("#f-res").value,
      start: +$("#f-start").value,
      end: +$("#f-end").value,
      detector: $("#f-det").value,
    },
    start_now: startNow,
  };
}

async function submitJob(startNow) {
  const msg = $("#form-msg");
  msg.textContent = "…";
  try {
    const r = await API.req("/api/jobs", { method: "POST", body: JSON.stringify(formPayload(startNow)) });
    msg.className = "msg ok";
    msg.textContent = startNow ? "started · " + r.job.id.slice(0, 8) : "staged · " + r.job.id.slice(0, 8);
    toast(startNow ? "Measurement started" : "Job added to queue");
    $("#f-name").value = "";
    refreshQueue();
    if (startNow) show("live");
  } catch (e) {
    msg.className = "msg err";
    msg.textContent = e.message;
    if (e.status === 401) promptToken();
  }
}
$("#btn-add").onclick = () => submitJob(false);
$("#btn-add-start").onclick = () => submitJob(true);

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g,
    c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function shortDt(s) { return s ? s.replace("T", " ").slice(0, 16) : "—"; }

async function refreshQueue() {
  try {
    const r = await API.req("/api/jobs?limit=200");
    const rows = (r.jobs || []).map(j => {
      const st = j.status;
      const acts = [];
      if (st === "staged") {
        acts.push(`<button class="rowbtn primary" data-act="start" data-id="${j.id}">start</button>`);
        acts.push(`<button class="rowbtn" data-act="edit" data-id="${j.id}">edit</button>`);
        acts.push(`<button class="rowbtn danger" data-act="del" data-id="${j.id}">✕</button>`);
      } else if (st === "running") {
        acts.push(`<button class="rowbtn danger" data-act="stop" data-id="${j.id}">■ stop</button>`);
      }
      const when = st === "running" ? (j.started || "…") : (j.finished || j.created);
      return `<tr data-id="${j.id}">
        <td><span class="tpill ${st}">${st}</span></td>
        <td>${esc(j.kind)}</td>
        <td>${esc(j.name)}</td>
        <td class="hint">${esc(j.paramsSummary || "")}</td>
        <td class="hint">${esc(shortDt(when))}</td>
        <td>${acts.join(" ")}</td></tr>`;
    }).join("");
    const tbody = $("#queue-table tbody");
    tbody.innerHTML = rows;
    $("#queue-empty").style.display = rows ? "none" : "";
    tbody.onclick = onQueueAction;
  } catch (e) {
    if (e.status === 401) promptToken();
  }
}

async function onQueueAction(ev) {
  const btn = ev.target.closest("button[data-act]");
  if (!btn) return;
  const id = btn.dataset.id, act = btn.dataset.act;
  try {
    if (act === "start") {
      await API.req(`/api/jobs/${id}/start`, { method: "POST" });
      toast("Started " + id.slice(0, 8));
      show("live");
    } else if (act === "stop") {
      await API.req(`/api/jobs/${id}/stop`, { method: "POST" });
      toast("Stop requested — engine aborts within ~5 s");
    } else if (act === "del") {
      if (confirm("Remove this job from the queue?")) await API.req(`/api/jobs/${id}`, { method: "DELETE" });
    } else if (act === "edit") {
      const j = (await API.req(`/api/jobs/${id}`)).job;
      const name = prompt("Name", j.name);
      if (name === null) return;
      let notes = prompt("Notes", j.notes || "");
      if (notes === null) notes = j.notes || "";
      let scans = prompt("Scans", (j.params || {}).scans ?? 10);
      if (scans === null) scans = 10;
      let res = prompt("Resolution", (j.params || {}).resolution ?? 4);
      if (res === null) res = 4;
      let st = prompt("Start (cm-1)", (j.params || {}).startFrequency ?? 400);
      if (st === null) st = 400;
      let en = prompt("End (cm-1)", (j.params || {}).endFrequency ?? 4000);
      if (en === null) en = 4000;
      const r = await API.req(`/api/jobs/${id}`, {
        method: "PATCH",
        body: JSON.stringify({
          name: name || j.name, notes,
          params: {
            ...j.params,
            scans: +scans, resolution: +res,
            startFrequency: +st, endFrequency: +en,
          },
        }),
      });
      toast("Updated " + r.job.id.slice(0, 8));
    }
    refreshQueue();
  } catch (e) {
    toast(e.message, true);
    if (e.status === 401) promptToken();
  }
}

/* ------------------------------------------------------------------ live */
let LIVE_T = null;
async function refreshLive(initial) {
  let h;
  try { h = await API.req("/health"); } catch (e) { liveOffline(e); return; }
  const busy = h.busy;
  $("#lv-state").textContent = busy ? "RUNNING" : "idle";
  $("#lv-state").style.color = busy ? "var(--warn)" : "var(--dim)";
  $("#lv-phase").textContent = h.phase || "idle";
  $("#lv-engine").textContent = h.connected ? "connected" : "not connected";
  const dot = $("#rail-dot");
  dot.className = "dot " + (busy ? "busy" : (h.connected ? "ok" : "dim"));

  if (busy && h.current) {
    try {
      const j = (await API.req(`/api/jobs/${h.current}`)).job;
      $("#lv-job").textContent = `${j.name}  (${j.kind})  ${j.id.slice(0, 8)}`;
      if (j.live && j.live.phaseSeconds != null)
        $("#lv-elapsed").textContent = j.live.phaseSeconds + " s in phase";
      $("#btn-stop").hidden = false;
      $("#live-progress").classList.remove("hidden");
    } catch (e) { /* job vanished mid-poll */ }
  } else {
    $("#lv-job").textContent = "—";
    $("#lv-elapsed").textContent = "—";
    $("#btn-stop").hidden = true;
    $("#live-progress").classList.add("hidden");
  }
  try {
    const st = (await API.req("/api/instrument/status")).instrument;
    $("#lv-ready").textContent = st.readyState ? st.readyState + (st.description ? " — " + st.description : "") : (st.phase || "—");
    $("#lv-bg").textContent = bgText(st.background);
  } catch (e) { $("#lv-bg").textContent = "—"; $("#lv-ready").textContent = "—"; }

  // event log: jobs list order is a good proxy (statuses + timestamps)
  try {
    const js = (await API.req("/api/jobs?limit=6")).jobs || [];
    $("#live-log").textContent = js.map(j =>
      `[${(j.finished || j.started || j.created) || ""}] ${j.status.padEnd(9)} ${j.kind.padEnd(10)} ${j.name}` +
      (j.error ? `  -> ${j.error.slice(0, 120)}` : "")).join("\n") || "no activity yet";
  } catch (e) { /* ignore */ }

  refreshBanners(h);
  const t0 = Date.now() + 2000;
  clearInterval(LIVE_T);
  LIVE_T = null;
}
$("#btn-stop").onclick = async () => {
  if (!confirm("Stop the running measurement? The engine aborts the scan (within ~5 s).")) return;
  try {
    const h = await API.req("/health");
    if (!h.current) return toast("nothing running", true);
    await API.req(`/api/jobs/${h.current}/stop`, { method: "POST" });
    toast("Stop requested");
    refreshLive();
  } catch (e) { toast(e.message, true); }
};
function liveOffline(e) {
  $("#lv-state").textContent = "offline";
  $("#lv-state").style.color = "var(--err)";
}
function bgText(bg) {
  if (!bg) return "—";
  if (!bg.ok) return bg.measuredAt ? `EXPIRED (${bg.ageHours} h old, limit ${bg.maxAgeHours} h)` : "none measured";
  return `ok · ${bg.ageHours} h old (limit ${bg.maxAgeHours} h)`;
}

/* --------------------------------------------------------------- results */
async function refreshResults() {
  try {
    const h = await API.req("/health");
    $("#res-dir").textContent = h.resultsDir;
    const sv = $("#sv-push");
  } catch (e) { if (e.status === 401) promptToken(); }
  let r;
  try { r = await API.req("/api/finished"); } catch (e) { return; }
  const rows = (r.measurements || [])
    .sort((a, b) => (b.finished || "").localeCompare(a.finished || ""))
    .map(m => `<tr data-id="${m.id}" class="rrow">
        <td class="hint">${esc(shortDt(m.finished))}</td>
        <td>${esc(m.kind)}</td>
        <td>${esc(m.name)}</td>
        <td>${m.n ?? "—"}</td>
        <td>${m.peaks ?? "—"}</td>
        <td><span class="tpill ${m.status}">${m.status}</span></td>
        <td class="hint">${esc(m.push_status || "—")}</td>
        <td><a class="rowbtn" href="${API.url(`/api/finished/${m.id}/file/${esc((m.files || [])[0] ? m.files[0].split(/[\\/]/).pop() : "")}`)}" target="_blank">file ↧</a></td>
    </tr>`).join("");
  $("#res-table tbody").innerHTML = rows;
  $("#res-empty").style.display = rows ? "none" : "";
  $$("#res-table tbody .rrow").forEach(tr => tr.onclick = ev => {
    if (ev.target.closest("a")) return;
    openResult(tr.dataset.id);
  });
  if ((r.measurements || []).length) openResult((r.measurements
    .sort((a, b) => (b.finished || "").localeCompare(a.finished || ""))[0]).id);
}

async function openResult(id) {
  $("#rd-title").textContent = "Spectrum — " + id.slice(0, 8);
  try {
    const { measurement: m } = await API.req(`/api/finished/${id}?spectrum=1`);
    $("#rd-err").textContent = (m.status === "finished" ? "" : "job " + m.status + (m.error ? ": " + m.error : ""));
    const chips = [
      ["n", m.result && m.result.n],
      ["unit", m.result && m.result.unit],
      ["range", m.result ? m.result.xMin + "–" + m.result.xMax + " cm⁻¹" : null],
      ["mean", m.result && m.result.stats ? (+m.result.stats.mean).toFixed(3) : null],
      ["min", m.result && m.result.stats ? m.result.stats.min : null],
      ["max", m.result && m.result.stats ? m.result.stats.max : null],
      ["push", m.push_status || "off"],
    ].filter(c => c[1] != null);
    $("#rd-chips").innerHTML = chips.map(c => `<span class="chip">${c[0]} <b>${esc(c[1])}</b></span>`).join("");

    if (m.spectrum && m.spectrum.x && m.spectrum.x.length) {
      drawSpectrum($("#rd-canvas"), m.spectrum.x, m.spectrum.y, m.spectrum.peaks || []);
      $("#rd-canvas").closest(".card").hidden = false;
    } else {
      $("#rd-canvas").closest(".card").hidden = (m.status !== "finished");
      if (!m.result || !m.result.sourceFile) $("#rd-err").textContent += " (no decodable vector)";
    }
    const base = (m.result && m.result.sourceFile) ? (m.result.sourceFile.split(/[\\/]/).pop()) : "";
    const csv = (m.files || []).find(f => /\.csv$/i.test(f));
    const xml = base || (m.files || [])[0];
    linkHref($("#rd-csv"), m.status === "finished" && csv ? API.url(`/api/finished/${id}/file/${csv.split(/[\\/]/).pop()}`) : "#");
    linkHref($("#rd-xml"), xml ? API.url(`/api/finished/${id}/file/${xml.split(/[\\/]/).pop()}`) : "#");
  } catch (e) {
    $("#rd-err").textContent = e.message;
  }
}
function linkHref(a, href) {
  if (href && href !== "#") { a.href = href; a.style.visibility = "visible"; }
  else { a.href = "#"; a.style.visibility = "hidden"; }
}

/* ------------------------- canvas spectrum plot (vanilla, dependency-free) */
function drawSpectrum(cv, xs, ys, peaks) {
  const DPR = window.devicePixelRatio || 1;
  const W = cv.clientWidth || 1100, H = 420;
  cv.width = W * DPR; cv.height = H * DPR;
  cv.style.height = H + "px";
  const x = cv.getContext("2d");
  x.setTransform(DPR, 0, 0, DPR, 0, 0);
  x.clearRect(0, 0, W, H);

  const L = 64, R = 16, T = 18, B = 42;
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  let y0 = Math.min(...ys), y1 = Math.max(...ys);
  if (y1 - y0 < 1e-9) { y1 += 1; y0 -= 1; }
  const pad = (y1 - y0) * 0.07; y0 -= pad; y1 += pad;
  const px = v => L + (v - x0) / (x1 - x0) * (W - L - R);
  const py = v => T + (1 - (v - y0) / (y1 - y0)) * (H - T - B);

  // grid + y ticks (5), x ticks (6)
  x.font = "11px ui-monospace, monospace";
  x.fillStyle = "#5b6c80";
  x.strokeStyle = "#1d2836";
  const ystep = (y1 - y0) / 5, xstep = (x1 - x0) / 6;
  for (let i = 0; i <= 5; i++) {
    const v = y0 + i * ystep, yy = py(v);
    x.beginPath(); x.moveTo(L, yy); x.lineTo(W - R, yy); x.stroke();
    x.fillText(v.toFixed(Math.abs(y1 - y0) > 50 ? 1 : 3), 8, yy + 4);
  }
  for (let i = 0; i <= 6; i++) {
    const v = x0 + i * xstep;
    x.fillText(v.toFixed(0), px(v) - 14, H - B + 18);
  }
  x.fillText("cm⁻¹", W - R - 34, H - B + 34);

  // trace (downsample to ~2*W points)
  const STEP = Math.max(1, Math.floor(xs.length / (W * 2)));
  x.beginPath();
  let first = true;
  for (let i = 0; i < xs.length; i += STEP) {
    const xx = px(xs[i]), yy = py(Math.max(y0, Math.min(y1, ys[i])));
    if (first) { x.moveTo(xx, yy); first = false; } else x.lineTo(xx, yy);
  }
  x.strokeStyle = "#4dd2a0";
  x.lineWidth = 1.4;
  x.stroke();

  // axis frame
  x.strokeStyle = "#33445c";
  x.strokeRect(L, T, W - L - R, H - T - B);

  // peaks
  peaks.slice(0, 12).forEach((p, i) => {
    const xx = px(p.x), yy = py(Math.max(y0, Math.min(y1, p.y)));
    x.beginPath(); x.arc(xx, yy, 3.2, 0, Math.PI * 2);
    x.fillStyle = i === 0 ? "#ffd166" : "#7fb2ff"; x.fill();
    if (i < 4) x.fillStyle = "#cfe2ff", x.fillText(p.x.toFixed(1), Math.min(xx + 6, W - 70), yy - 8);
  });
}

/* ------------------------------------------------------------- settings */
async function refreshSettings() {
  try {
    const h = await API.req("/health");
    $("#sv-ver").textContent = h.version;
    $("#sv-uptime").textContent = Math.floor(h.uptime_s / 60) + " min";
    $("#sv-token").textContent = h.tokenRequired ? "X-Fishy-Token required (see console/config)" : "off (loopback)";
    $("#sv-dir").textContent = h.resultsDir;
    $("#sv-push").textContent = "(see config push.url)";
  } catch (e) { if (e.status === 401) promptToken(); }
  try {
    const st = (await API.req("/api/instrument/status")).instrument;
    $("#st-ready").textContent = st.readyState || (st.busy ? "busy: " + st.phase : "—");
    $("#st-session").textContent = st.session || "not connected yet (lazy)";
    $("#st-bgrule").textContent = st.background
      ? `last BKG ${st.background.measuredAt || "never"} · limit ${st.background.maxAgeHours} h`
      : "—";
    if (st.background && !st.background.ok) $("#st-bgrule").textContent += "  ⚠ " + (st.background.warning || "");
  } catch (e) {
    $("#st-ready").textContent = "offline (" + e.message + ")";
  }
  try { $("#st-time").textContent = (await API.req("/api/instrument/time")).time; } catch (e) {}
}
$("#btn-st-refresh").onclick = refreshSettings;
$("#btn-opt").onclick = async () => {
  const out = $("#opt-out");
  out.textContent = "asking engine…";
  try {
    const d = await API.req("/api/settings/optimal?detector=TGSA");
    const v = d.optimal || d;
    out.className = "msg ok";
    out.textContent = JSON.stringify(v).slice(0, 160);
  } catch (e) { out.className = "msg err"; out.textContent = e.message; }
};
$("#btn-push-test").onclick = async () => {
  const m = $("#push-msg");
  m.textContent = "firing push…";
  try {
    const r = await API.req("/api/push/test", { method: "POST" });
    m.className = r.ok ? "msg ok" : "msg err";
    m.textContent = `remote: ${r.status} ${r.ok ? "OK" : "rejected"}`;
  } catch (e) { m.className = "msg err"; m.textContent = e.message; }
};

/* ------------------------------------------------------------------- api */
async function refreshApi() {
  try {
    const d = await API.req("/api/docs");
    $("#api-auth").textContent = d.auth + (API.token ? "  ·  token set in this browser" : "");
    document.querySelector("#api-table tbody").innerHTML = (d.endpoints || [])
      .map(e => `<tr><td><code>${e.m}</code></td><td><code>${e.p}</code></td><td class="hint">${esc(e.d)}</td></tr>`)
      .join("");
  } catch (e) { /* offline */ }
  if (API.token) {
    const sv = $("#sv-token"); if (sv) sv.textContent = "set in this browser (localStorage)";
  }
  $("#btn-push-test").hidden = false;
}

/* ------------------------------------------------------------ token prompt */
function promptToken() {
  const t = prompt("REST token (printed at service start, also in config/fishy_ir.token):");
  if (t !== null) API.setToken(t.trim());
  toast(t ? "token stored in this browser" : "token required for /api/* calls", !t);
}

/* ------------------------------------------------------------- boot ----- */
async function pollHealth() {
  try {
    const h = await API.req("/health");
    $("#rail-ver").textContent = h.version;
    const e = $("#eng-pill");
    if (h.busy) { e.className = "pill warn busy"; e.textContent = "measuring…"; }
    else if (h.connected) { e.className = "pill ok"; e.textContent = "engine ready"; }
    else { e.className = "pill dim"; e.textContent = "engine —"; }
    const bg = $("#bg-pill"), b = h.background;
    if (b && !b.ok) { bg.className = "pill warn"; bg.textContent = "BKG stale"; }
    else if (b && b.ok) { bg.className = "pill ok"; bg.textContent = "BKG ok"; }
    refreshBanners(h);
    if (VIEW === "live") refreshLive();
  } catch (err) {
    const e = $("#eng-pill");
    e.className = "pill err"; e.textContent = "service offline";
    $("#rail-dot").className = "dot err";
  }
}
pollHealth();
setInterval(pollHealth, 3000);
show("queue");
